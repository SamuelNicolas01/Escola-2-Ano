package etec.com.br.samuelnicolas.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Pergunta3 extends AppCompatActivity {
    RadioGroup rgOpcoes;
    Button btAvancar3;
    String nome;
    int pontos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta3);

        rgOpcoes = findViewById(R.id.rgOpcoesp3);
        btAvancar3 = findViewById(R.id.btnAvancarP3);

        Intent telaAtual = getIntent();
        Bundle dados = telaAtual.getExtras();

        nome = dados.getString("nome");
        pontos = dados.getInt("pontos");

        Toast.makeText(this, "Nome: " + nome + " | Pontos: " + pontos,
                Toast.LENGTH_LONG).show();

        btAvancar3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int escolha = rgOpcoes.getCheckedRadioButtonId();

                if (escolha == -1){
                    Toast.makeText(Pergunta3.this,"Selecione Uma Opção!",Toast.LENGTH_SHORT).show();
                    return;
                }

                if (escolha == R.id.rbtP4d) {
                    Intent abrirP4 = new Intent(Pergunta3.this, Pergunta4.class);

                    abrirP4.putExtra("nome", nome);
                    abrirP4.putExtra("pontos", pontos + 1);

                    startActivity(abrirP4);
                    finish();
                }
                Intent abrirP4 = new Intent(Pergunta3.this, Pergunta4.class);
                abrirP4.putExtra("nome",nome);
                abrirP4.putExtra("pontos",pontos);

                startActivity(abrirP4);
                finish();            }
        });
    }
}