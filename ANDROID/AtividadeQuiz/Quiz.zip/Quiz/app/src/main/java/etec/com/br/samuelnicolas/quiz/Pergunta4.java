package etec.com.br.samuelnicolas.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Pergunta4 extends AppCompatActivity {
    RadioGroup rgOpcoes;
    Button btAvancar3;
    String nome;
    int pontos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta4);

        rgOpcoes = findViewById(R.id.rgOpcoesp3);
        btAvancar3 = findViewById(R.id.btnAvancarP3);

        Intent telaAtual = getIntent();
        Bundle dados = telaAtual.getExtras();

        nome = dados.getString("nome");
        pontos = dados.getInt("pontos");

        Toast.makeText(this, "Nome: " + nome + " | Pontos: " + pontos,
                Toast.LENGTH_LONG).show();
    }
}