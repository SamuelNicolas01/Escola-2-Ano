package etec.com.br.samuelnicolas.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Pergunta2 extends AppCompatActivity {
    RadioGroup rgOpcoes;
    Button btAvancar2;
    String nome;
    int pontos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta2);

        rgOpcoes = findViewById(R.id.rgOpcoesp2);
        btAvancar2 = findViewById(R.id.btnAvancarP2);

        Intent telaAtual = getIntent();
        Bundle dados = telaAtual.getExtras();



        nome = dados.getString("nome");
        pontos = dados.getInt("pontos");

        Toast.makeText(this, "Nome: " + nome + " | Pontos: " + pontos,
                Toast.LENGTH_LONG).show();

        btAvancar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int escolha = rgOpcoes.getCheckedRadioButtonId();

                if (escolha == -1){
                    Toast.makeText(Pergunta2.this, "Selecione uma opção!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (escolha == R.id.rbtP2c){
                    Intent abrirP3 = new Intent(Pergunta2.this,Pergunta3.class);

                    abrirP3.putExtra("nome", nome);
                    pontos = pontos + 1;
                    abrirP3.putExtra("pontos",pontos + 1 );

                    startActivity(abrirP3);

                    finish();
                }
                    Intent abrirP3 = new Intent(Pergunta2.this, Pergunta3.class);
                    abrirP3.putExtra("nome",nome);
                    abrirP3.putExtra("pontos",pontos);

                    startActivity(abrirP3);
                    finish();
            }
        });
    }
}