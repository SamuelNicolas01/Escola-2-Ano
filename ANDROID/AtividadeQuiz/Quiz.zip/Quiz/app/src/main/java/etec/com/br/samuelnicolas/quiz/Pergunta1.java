package etec.com.br.samuelnicolas.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Pergunta1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta1);
    }
}