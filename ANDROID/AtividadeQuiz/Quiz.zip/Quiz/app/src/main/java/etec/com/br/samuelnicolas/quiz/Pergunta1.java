package etec.com.br.samuelnicolas.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

public class Pergunta1 extends AppCompatActivity {
    RadioGroup rgOpcoes;
    Button btAvancar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta1);
        rgOpcoes = findViewById(R.id.rgOpcoesp1);
        btAvancar = findViewById(R.id.btnAvancar);

        Intent telaP1 = getIntent();

        Bundle dados = telaP1.getExtras();

        String nomeRecebido;

        //pegando dados
        nomeRecebido = dados.getString("nome");

        btAvancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome;
                int escolha,pontuacao;
                escolha = rgOpcoes.getCheckedRadioButtonId();
                if (escolha == R.id.rbtP1a){
                    pontuacao = 1;
                }
            }
        });
    }
}