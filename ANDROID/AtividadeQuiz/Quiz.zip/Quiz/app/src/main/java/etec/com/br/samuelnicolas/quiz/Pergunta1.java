package etec.com.br.samuelnicolas.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Pergunta1 extends AppCompatActivity {
    RadioGroup rgOpcoes;
    Button btAvancar;
    int pontos = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta1);

        rgOpcoes = findViewById(R.id.rgOpcoesp1);
        btAvancar = findViewById(R.id.btnAvancarP1);

        String nome = getIntent().getStringExtra("nome");

        btAvancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int escolha = rgOpcoes.getCheckedRadioButtonId();

                if (escolha == -1) {
                    Toast.makeText(Pergunta1.this,
                            "Selecione uma opção!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (escolha == R.id.rbtP1a) {
                    pontos = 1;
                    finish();
                }

                Intent abrirP2 = new Intent(Pergunta1.this, Pergunta2.class);

                abrirP2.putExtra("nome", nome);
                abrirP2.putExtra("pontos", pontos);

                startActivity(abrirP2);
            }
        });
    }
}