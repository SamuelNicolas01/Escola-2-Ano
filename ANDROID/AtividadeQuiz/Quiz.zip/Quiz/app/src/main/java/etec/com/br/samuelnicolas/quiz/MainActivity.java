package etec.com.br.samuelnicolas.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText edNome;
    Button btIniciar,btSobre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edNome = findViewById(R.id.edtNome);
        btIniciar = findViewById(R.id.btnIniciar);
        btSobre = findViewById(R.id.btnSobre);

        //BOTÃO INICIAR
        btIniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (edNome.getText().toString().isEmpty()) {
                    edNome.setError("Nome Obrigatório");
                    edNome.requestFocus();
                }
                else{
                    String nome;
                    nome = edNome.getText().toString();

                    Intent abrirPergunta1 = new Intent(MainActivity.this,Pergunta1.class);

                    abrirPergunta1.putExtra("nome",nome);

                    startActivity(abrirPergunta1);
                }
            }
        });
        //BOTÃO SOBRE
        btSobre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent abrirSobre = new Intent(MainActivity.this,Sobre.class);

                startActivity(abrirSobre);
            }
        });
    }
}