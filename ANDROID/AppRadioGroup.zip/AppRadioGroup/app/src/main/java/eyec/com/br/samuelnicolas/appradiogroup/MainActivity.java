package eyec.com.br.samuelnicolas.appradiogroup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup rgOpcoes;
    Button btConferir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rgOpcoes = findViewById(R.id.rgpOpcoes);
        btConferir = findViewById(R.id.btnConferir);

        btConferir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int escolha;
                escolha = rgOpcoes.getCheckedRadioButtonId();
                if ( escolha == R.id.rbtUm){
                    Toast.makeText(MainActivity.this, "Você clicou no radio 1", Toast.LENGTH_SHORT).show();
                } else if (escolha == R.id.rbtDois){
                    Toast.makeText(MainActivity.this, "Você clicou no radio 2", Toast.LENGTH_SHORT).show();
                } else if (escolha == R.id.rbtTres){
                    Toast.makeText(MainActivity.this, "Você clicou no radio 3", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Selecione uma opção", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}