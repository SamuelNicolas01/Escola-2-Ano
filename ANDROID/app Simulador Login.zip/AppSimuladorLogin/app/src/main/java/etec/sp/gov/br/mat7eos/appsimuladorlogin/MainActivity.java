package etec.sp.gov.br.mat7eos.appsimuladorlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editUsuario;
    EditText editSenha;
    Button btnLogar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editUsuario = findViewById(R.id.editUsuario);
        editSenha = findViewById(R.id.editSenha);
        btnLogar = findViewById(R.id.btnLogar);

        btnLogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usuario = editUsuario.getText().toString().trim();
                String senha = editSenha.getText().toString().trim();

                if (usuario.isEmpty() || senha.isEmpty()) {
                    Toast.makeText(MainActivity.this, getString(R.string.msg_preencher_campos), Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(MainActivity.this, Tela2.class);
                    intent.putExtra(getString(R.string.extra_usuario), usuario);
                    intent.putExtra(getString(R.string.extra_senha), senha);
                    startActivity(intent);
                }
            }
        });
    }
}
