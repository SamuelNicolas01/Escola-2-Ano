package etec.sp.gov.br.mat7eos.appsimuladorlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Tela2 extends AppCompatActivity {

    TextView txtBoasVindas;
    Button btnSair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);

        txtBoasVindas = findViewById(R.id.txtBoasVindas);
        btnSair = findViewById(R.id.btnSair);

        String usuario = getIntent().getStringExtra(getString(R.string.extra_usuario));
        String senha = getIntent().getStringExtra(getString(R.string.extra_senha));

        String usuarioCorreto = getString(R.string.usuario_correto);
        String senhaCorreta = getString(R.string.senha_correta);

        if (usuario != null && senha != null && usuario.equals(usuarioCorreto) && senha.equals(senhaCorreta)) {
            txtBoasVindas.setText(getString(R.string.msg_boas_vindas, usuario));

            btnSair.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
        } else {
            Toast.makeText(this, getString(R.string.msg_login_invalido), Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}
