package etec.com.br.pedrosousa.apppesoideal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DecimalFormat;

public class TelaFeminino extends AppCompatActivity {

    Button btCalcFem, btVoltaFem;
    EditText edAltFem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_feminino);
        btCalcFem = findViewById(R.id.btnCalcFem);
        btVoltaFem = findViewById(R.id.btnVoltaFem);
        edAltFem = findViewById(R.id.edtAltFem);

        btCalcFem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edAltFem.getText().toString().isEmpty()) {
                    edAltFem.setError("VOCÊ PRECISA COLOCAR UM VALOR");
                    edAltFem.requestFocus();
                } else if (edAltFem.getText().toString().equals(".")) {
                    edAltFem.setError("Valor inválido");
                    edAltFem.requestFocus();
                } else {
                    float pesoIdeal, altura;

                    altura = Float.parseFloat(edAltFem.getText().toString());
                    pesoIdeal = (62.1f * altura) - 44.7f;
                    DecimalFormat df = new DecimalFormat("0.00");
                    Toast.makeText(TelaFeminino.this, "Seu peso ideal é = "+ df.format(pesoIdeal), Toast.LENGTH_SHORT).show();
                }
            }
        });
        btVoltaFem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Clique no botão Voltar do app", Toast.LENGTH_SHORT).show();
    }
}