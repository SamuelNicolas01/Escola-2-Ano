package etec.com.br.pedrosousa.apppesoideal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DecimalFormat;

public class TelaMasculino extends AppCompatActivity {

    Button btCalcMasc, btVoltaMasc;
    EditText edAltMasc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_masculino);
        btCalcMasc = findViewById(R.id.btnCalcMasc);
        btVoltaMasc = findViewById(R.id.btnVoltaMasc);
        edAltMasc = findViewById(R.id.edtAltMasc);

        btCalcMasc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edAltMasc.getText().toString().isEmpty()) {
                    edAltMasc.setError("VOCÊ PRECISA COLOCAR UM VALOR");
                    edAltMasc.requestFocus();
                } else if (edAltMasc.getText().toString().equals(".")) {
                    edAltMasc.setError("Valor inválido");
                    edAltMasc.requestFocus();
                } else {
                    float pesoIdeal, altura;

                    altura = Float.parseFloat(edAltMasc.getText().toString());
                    pesoIdeal = (72.7f * altura) - 58f;
                    DecimalFormat df = new DecimalFormat("0.00");
                    Toast.makeText(TelaMasculino.this, "Seu peso ideal é = "+ df.format(pesoIdeal), Toast.LENGTH_SHORT).show();
                }
            }
        });
        btVoltaMasc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Clique no botão Voltar do app", Toast.LENGTH_SHORT).show();
    }
}
