package etec.com.br.pedrosousa.apppesoideal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btMasc, btFem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btMasc = findViewById(R.id.btnMasc);
        btFem = findViewById(R.id.btnFem);

        btMasc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent abrirTelaMasc = new Intent(MainActivity.this,TelaMasculino.class);
                startActivity(abrirTelaMasc);
            }
        });

        btFem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent abrirTelaFem = new Intent(MainActivity.this,TelaFeminino.class);
                startActivity(abrirTelaFem);
            }
        });
    }
}