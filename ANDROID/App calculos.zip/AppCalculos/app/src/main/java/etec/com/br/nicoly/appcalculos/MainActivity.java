package etec.com.br.nicoly.appcalculos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //objetos java para diferenciar com os objetos xml
    EditText edValor1, edValor2;
    Button btSomar, btSubtracao, btMultiplicacao, btDivisao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //referenciando os objetos java e xml
        //$valor1 = $_GET('txtValor1');
        edValor1 = findViewById(R.id.edtValor1);
        edValor2 = findViewById(R.id.edtValor2);
        btSomar = findViewById(R.id.btnSomar);
        btSubtracao = findViewById(R.id.btnSubtracao);
        btMultiplicacao = findViewById(R.id.btnMultiplicacao);
        btDivisao = findViewById(R.id.btnDivisao);

        //preparando o clique do botão somar
        btSomar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //verificando se valor1 esta vazio
                if (edValor1.getText().toString().isEmpty()) {
                    //exibindo o alerta
                    edValor1.setError("Valor 1 obrigatório");
                    //ir para a valor1
                    edValor1.requestFocus();
                }
                //verificando se valor1 tem apenas um ponto
                else if(edValor1.getText().toString().equals(".")){
                    //exibindo o alerta
                    edValor1.setError("Valor 1 inválido");
                    //ir para valor 1
                    edValor1.requestFocus();
                }
                //verificando se valor 2 esta vazio
                else if(edValor2.getText().toString().isEmpty()){
                    //exibindo o alerta
                    edValor2.setError("Valor 2 obrigatório");
                    //ir para valor 2
                    edValor2.requestFocus();
                }
                //verificando se o valor 2 tem apenas um ponto
                else if(edValor2.getText().toString().equals(".")){
                    //exibindo o alerta
                    edValor2.setError("Valor 2 inválido");
                    //ir para valor 2
                    edValor2.requestFocus();
                }
                //senão
                else{
                    //variaveis auxiliares
                    float valor1,valor2,resultado;
                    //pegar os valores
                    valor1 = Float.parseFloat(edValor1.getText().toString());
                    valor2 = Float.parseFloat(edValor2.getText().toString());

                    resultado = valor1 + valor2;

                    Toast.makeText(MainActivity.this, "A soma é"+resultado, Toast.LENGTH_SHORT).show();

                }



            }
        });

        //preparando o clique do botão subtrair
        btSubtracao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(edValor1.getText().toString().isEmpty()){

                    edValor1.setError("Valor 1 obrigatório");
                    edValor1.requestFocus();
                }

                else if(edValor1.getText().toString().equals(".")){

                    edValor1.setError("Valor 1 inválido");
                    edValor1.requestFocus();
                }

                else if(edValor2.getText().toString().isEmpty()){

                    edValor2.setError("Valor 2 obrigatório");
                    edValor2.requestFocus();
                }

                else if(edValor2.getText().toString().equals(".")){

                    edValor2.setError("Valor 2 inválido");
                    edValor2.requestFocus();
                }

                else{
                    float valor1,valor2,resultado;
                    valor1 = Float.parseFloat(edValor1.getText().toString());
                    valor2 = Float.parseFloat(edValor2.getText().toString());

                    resultado = valor1 - valor2;

                    Toast.makeText(MainActivity.this, "A subtracao é"+resultado, Toast.LENGTH_SHORT).show();
                }
            }
        });

        //preprando o clique do botão multiplicar

        btMultiplicacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (edValor1.getText().toString().isEmpty()){

                    edValor1.setError("Valor 1 obrigatório");
                    edValor1.requestFocus();
                }

                else if(edValor1.getText().toString().equals(".")){

                    edValor1.setError("Valor 1 inválido");
                    edValor1.requestFocus();
                }

                else if(edValor2.getText().toString().isEmpty()){

                    edValor2.setError("Valor 2 obrigatório");
                    edValor2.requestFocus();
                }

                else if(edValor2.getText().toString().equals(".")){

                    edValor2.setError("Valor 2 inválido");
                    edValor2.requestFocus();
                }
                else{
                    float valor1,valor2,resultado;

                    valor1 = Float.parseFloat(edValor1.getText().toString());
                    valor2 = Float.parseFloat(edValor2.getText().toString());

                    resultado = valor1 * valor2;

                    Toast.makeText(MainActivity.this, "A multiplicacao é"+resultado, Toast.LENGTH_SHORT).show();
                }
            }
        });

        //preparando o clique do botão dividir
        btDivisao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edValor1.getText().toString().isEmpty()){

                    edValor1.setError("Valor 1 obrigatório");
                    edValor1.requestFocus();
                }
                 else if(edValor1.getText().toString().equals(".")){
                     edValor1.setError("Valor 1 inválido");
                     edValor1.requestFocus();
                }

                 else if(edValor2.getText().toString().isEmpty()){
                     edValor2.setError("Valor 2 obrigatório");
                     edValor2.requestFocus();
                }

                 else if(edValor2.getText().toString().equals(".")){
                     edValor2.setError("Valor 2 inválido");
                     edValor2.requestFocus();
                }
               else{
                   float valor1,valor2,resultado;

                   valor1 = Float.parseFloat(edValor1.getText().toString());
                   valor2 = Float.parseFloat(edValor2.getText().toString());

                   resultado = valor1 / valor2;

                    Toast.makeText(MainActivity.this, "A divisao é"+resultado, Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}