package etec.com.br.samuelnicolas.appparametros;

import androidx.appcompat.app.AppCompatActivity;

import android.app.SearchManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    //OBJETOS PARA REFERENCIAR
        EditText edNome,edEmail;
        Button btConfirmar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //REFERENCIANDO
        edNome = findViewById(R.id.edtNome);
        edEmail = findViewById(R.id.edtEmail);
        btConfirmar = findViewById(R.id.btnConfirmar);

        //BOTÃO CONFITMAR
        btConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //VARIAVEIS AUXILIARES
                String nome,email;

                //GUARDANDO OS VALORES NAS VÁRIAVEIS
                nome = edNome.getText().toString();
                email = edEmail.getText().toString();

                //CRIANDO A INTENT PARA IR
                Intent abrirTela2 = new Intent(MainActivity.this,Tela2.class);

                //COLOCANDO OS DADOS NO PACOTE INTENT
                abrirTela2.putExtra("nome",nome);
                abrirTela2.putExtra("email",email);

                //EXECUTANDO A INTENT
                startActivity(abrirTela2);
                //
            }
        });
    }
}