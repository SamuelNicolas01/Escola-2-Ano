package etec.com.br.samuelnicolas.appparametros;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Tela2 extends AppCompatActivity {
    //OBJETOS PARA REFERENCIAR
    TextView txMostrarNome, txMostrarEmail;
    Button btVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);

        //REFERENCIANDO
        txMostrarNome = findViewById(R.id.txtMostraNome);
        txMostrarEmail = findViewById(R.id.txtMostraEmail);
        btVoltar = findViewById(R.id.btnVoltar);

        //INTENT PARA RECUPERAR OS DADOS
        Intent telaAtual = getIntent();
        //BUNDLE PARA ACESSAR OS DADOS DA INTENT
        Bundle dados = telaAtual.getExtras();

        //VARIÁVEIS AUXILIARES
        String nomeRecebido, emailRecebido;

        //PEGANDO OS DADOS
        nomeRecebido = dados.getString("nome");
        emailRecebido = dados.getString("email");

        //COLOCANDO OS DADOS DAS TEXTVIEWS
        txMostrarNome.setText(nomeRecebido);
        txMostrarEmail.setText(emailRecebido);

        //BOTÃO VOLTAR
        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}