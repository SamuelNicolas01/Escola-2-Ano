package etec.com.br.nicoly.appsimuladorlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Tela2 extends AppCompatActivity {

    TextView txNome;

    Button btSair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);

        txNome = findViewById(R.id.txtNome);
        btSair = findViewById(R.id.btnSair);

        Intent telaAtual = getIntent();

        Bundle dados = telaAtual.getExtras();

        String usuarioRecebido, senhaRecebida;

        //pegando os dados
        usuarioRecebido = dados.getString("usuario");
        senhaRecebida = dados.getString("senha");

        //verificar a senha
        if (senhaRecebida.equals("Etec123")){
            txNome.setText("Bem vindo(a),"+usuarioRecebido);
        }else{
            Toast.makeText(Tela2.this, "Usuário ou senha inválidos",Toast.LENGTH_SHORT).show();
            finish();
        }

        btSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}