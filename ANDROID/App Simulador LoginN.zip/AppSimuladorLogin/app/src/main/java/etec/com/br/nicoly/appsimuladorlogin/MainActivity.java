package etec.com.br.nicoly.appsimuladorlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText edUsuario, edSenha;
    Button btLogar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edUsuario = findViewById(R.id.edtUsuario);
        edSenha = findViewById(R.id.edtSenha);
        btLogar = findViewById(R.id.btnLogar);

        //botão logar
        btLogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(edUsuario.getText().toString().isEmpty()){

                   edUsuario.setError("Usuário obrigatório");
                   edUsuario.requestFocus();
                }
                else if (edSenha.getText().toString().isEmpty()){

                    edSenha.setError("Senha obrigatória");
                    edSenha.requestFocus();
                }
               else {
                    String usuario, senha;

                    usuario = edUsuario.getText().toString();
                    senha = edSenha.getText().toString();

                    Intent abrirTela2 = new Intent(MainActivity.this, Tela2.class);

                    abrirTela2.putExtra("usuario", usuario);
                    abrirTela2.putExtra("senha", senha);

                    startActivity(abrirTela2);
                }
            }
        });
    }
}