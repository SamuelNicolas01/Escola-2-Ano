package etec.com.br.nicoly.appintents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Tela2 extends AppCompatActivity {

    Button btVoltarT2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        btVoltarT2 = findViewById(R.id.btnVoltarT2);

        btVoltarT2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               finish();
            }
        });

        }
        //Bloquear o voltar do celular

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Clique no botão voltar do app", Toast.LENGTH_SHORT).show();
    }
}
