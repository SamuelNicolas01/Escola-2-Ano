package etec.com.br.nicoly.appintents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //objetos para diferenciar
    Button btTela2,btTela3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btTela2 = findViewById(R.id.btnTela2);
        btTela3 = findViewById(R.id.btnTela3);

        //botão Tela2
        btTela2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Função que abre a tela2
                Intent abrirTela2 = new Intent(MainActivity.this,Tela2.class);
                //executar a função
                startActivity(abrirTela2);
            }
        });

        //botão Tela3
        btTela3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent abrirTela3 = new Intent(MainActivity.this,Tela3.class);

                startActivity(abrirTela3);
            }
        });

    }
}