package etec.com.br.samuelnicolas.appconversor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    //objetos java para diferenciar com os objetos xml
    EditText edTemp;
    Button btCelsiusKelvin,btKelvinCelsius,btCelsiusFahre,btFahreCelsius,btKelvinFahre,btFahreKelvin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //referenciando os objetos java e xml
        edTemp= findViewById(R.id.edtTemp);
        btCelsiusKelvin = findViewById(R.id.btnCelsiuKelvin);
        btKelvinCelsius = findViewById(R.id.btnKelvinCelsius);
        btCelsiusFahre = findViewById(R.id.btnCelsiusFahre);
        btFahreCelsius = findViewById(R.id.btnFahreCelsius);
        btKelvinFahre = findViewById(R.id.btnKelvinFahre);
        btFahreKelvin = findViewById(R.id.btnFahreKelvin);

        //preparando clique do botão Celsius para Kelvin
        btCelsiusKelvin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            //verificando se edtTempo está vazio
            if (edTemp.getText().toString().isEmpty()){
                //exibindo alerta
                edTemp.setError("VOCÊ PRECISA COLOCAR UM VALOR");
                //ir para edTemp
                edTemp.requestFocus();
            }
            //verificar se tem apenas um ponto
                else if (edTemp.getText().toString().equals(".")){
                    //exibindo o alerta
                    edTemp.setError("Valor inválido");
                    //ir para edTemp
                    edTemp.requestFocus();
                }
            // calculo
            else {
                // variaveis auxiliares
                float K,C;
                // pegar valor de Celsius
                C = Float.parseFloat(edTemp.getText().toString());
                // conta
                K = C + 273.15f;
                // exibir resultado
                DecimalFormat df = new DecimalFormat("0.00");
                Toast.makeText(MainActivity.this, "O valor é = " +df.format(K), Toast.LENGTH_SHORT).show();
            }
            }
        });

        //preparando para o clique Kelvin para Celsius
        btKelvinCelsius.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // conferindo se edTemp esta vazio
                if (edTemp.getText().toString().isEmpty()){
                    //exibir alerta
                    edTemp.setError("VOCÊ PRECISA COLOCAR UM VALOR");
                    //ir para edTemp
                    edTemp.requestFocus();
                }
                // conferindo se edTemp é um ponto
                else if (edTemp.getText().toString().equals(".")){
                    //exibir alerta
                    edTemp.setError("Esse valor éinválido");
                    //ir para edTemp
                    edTemp.requestFocus();
                }
                // calculo
                else {
                    //variaveis auxiliares
                    float C,K;
                    //pegar valor de kelvin
                    K = Float.parseFloat(edTemp.getText().toString());
                    // conta
                    C = K - 273.15f;
                    //exibir resultado
                    DecimalFormat df = new DecimalFormat("0.00");
                    Toast.makeText(MainActivity.this, "O valor é = "+df.format(C), Toast.LENGTH_SHORT).show();
                }
            }
        });

        //preparando o clique de Celsius para Fahrenheit
        btCelsiusFahre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // verificando se edTemp está vazio
                if (edTemp.getText().toString().isEmpty()){
                    //exibindo alerta
                    edTemp.setError("VOCÊ PRECISA COLOCAR UM VALOR");
                    //ir para edTemp
                    edTemp.requestFocus();
                }
                //verificando se edTemp tem apenas um .
                else if (edTemp.getText().toString().equals(".")){
                    //exibir alerta
                    edTemp.setError("ESSE VALOR É INCÁLIDO");
                    //ir para edTemp
                    edTemp.requestFocus();
                }
                //calculo
                else{
                    //variaveis auxiliares
                    float C,F;
                    // atribuindo valor
                    C = Float.parseFloat(edTemp.getText().toString());
                    // conta
                    F = ( C * 1.8f) + 32f;
                    //exibir resultado
                    DecimalFormat df = new DecimalFormat("0.00");
                    Toast.makeText(MainActivity.this, "O valor é = "+df.format(F), Toast.LENGTH_SHORT).show();
                }
            }
        });
        // preparando clique do Fahrenheit para Celsius
        btFahreCelsius.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //verificando se edTemp esta vazio
                if (edTemp.getText().toString().isEmpty()) {
                    //exibindo alerta
                    edTemp.setError("VOCÊ PRECISA COLOCAR UM VALOR");
                    //ir para edTemp
                    edTemp.requestFocus();
                }
                //verificando se edTemp é um .
                else if (edTemp.getText().toString().equals(".")){
                    //exibindo alerta
                    edTemp.setError("VALOR INVÁLIDO");
                    //ir para edTemp
                    edTemp.requestFocus();
                }
                //calculo
                else{
                    // variaveis auxiliares
                    float F,C;
                   // atribuindo valor
                    F = Float.parseFloat(edTemp.getText().toString());
                    //conta
                    C = (F - 32f)*0.55555f;
                    //exibir resultados
                    DecimalFormat df = new DecimalFormat("0.00");
                    Toast.makeText(MainActivity.this, "O valor é = "+df.format(C), Toast.LENGTH_SHORT).show();
                }
            }
        });
        // preparando clique Kelvin para Fahrenheit
        btKelvinFahre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // verificando se o valor esta vazio
                if (edTemp.getText().toString().isEmpty()){
                    //exibindo alerta
                    edTemp.setError("VOCÊ PRECISA COLOCAR UM VALOR");
                    //ir poara edTemp
                    edTemp.requestFocus();
                }
                // verificando se edTemp é um .
                else if (edTemp.getText().toString().equals(".")){
                    //exibindo alerta
                    edTemp.setError("VALOR INVÁLIDO");
                    // ir para edTemp
                    edTemp.requestFocus();
                }
                //calculo
                else{
                //variveis auxiliares
                    float K,F;
                    //atribuindo valor
                    K = Float.parseFloat(edTemp.getText().toString());
                    //conta
                    F = ((K - 273.15f)) * 1.8f + 32f;
                    // exibir resultados
                    DecimalFormat df = new DecimalFormat("0.00");
                    Toast.makeText(MainActivity.this, "O valor é = "+df.format(F), Toast.LENGTH_SHORT).show();
                }
            }
        });
        //preparando clique para Fahrenheit para Kelvin
        btFahreKelvin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //verificando se o valor esta vazio
                if (edTemp.getText().toString().isEmpty()){
                    //exibindo alerta
                    edTemp.setError("VOCÊ PREISA COLOCAR UM VALOR");
                    //ir para edTemp
                    edTemp.requestFocus();
                }
                //verificando se edTemp é apenas um .
                else if (edTemp.getText().toString().equals(".")){
                    //exibindo alerta
                    edTemp.setError("VALOR INVÁLIDO");
                    // ir para edTemp
                    edTemp.requestFocus();
                }
                //calculo
                else{
                    //variaveis auxiliares
                    float F,K;
                    //atribuindo valor
                    F = Float.parseFloat(edTemp.getText().toString());
                    //conta
                    K = ( ( F - 32f) * 0.55555f ) + 273.15f;
                    //exibir resultados
                    DecimalFormat df = new DecimalFormat("0.00");
                    Toast.makeText(MainActivity.this, "O valor é = "+df.format(K), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}